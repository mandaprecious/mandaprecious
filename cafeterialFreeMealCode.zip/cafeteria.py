import os

login = False
def log_in(credintials):
    global login
    with open("attendant.txt", "r") as database:
        number = database.read()
        if str(credintials) == number:
            login = True
            message = "system logged in successfully"
        else:
            login = False
            message = "failed to login, please enter correct attendant credentials"
    return message
def add_gym_member(id):
    id = str(id)
    members_array =[]
    with open("gymMembers.txt", "r") as f:
        members = f.read()
        members_array = members.split(",")

    with open("gymMembers.txt", "a") as database:
        if id not in members_array:
            database.write(id + ",")
            message = f"user id {id} registered successfully"
        else:
            message= f"user id {id} already exist"
    return message

def remove_gym_member(id):
    id = str(id)
    with open("gymMembers.txt", "r") as f:
        members = f.read()
        members_array = members.split(",")
    if id not in members_array:
        message = f"user id {id} does not exist in the system"
    else:
        members_array.remove(id)
        with open("gymMembers.txt","w") as database:
            for member in members_array:
                database.write(member + ",")
        message = f"user id {id} removed successfully"
    return message

def issue_meal_card(id):
    id = str(id)
    with open("gymMembers.txt", "r") as f:
        members = f.read()
        members_array = members.split(",")
    if id in members_array:
        with open("issuedMeals.txt", "r") as f:
            members = f.read()
            issued_meals_array = members.split(",")
        if id not in issued_meals_array:
            with open("issuedMeals.txt", "a") as database:
                database.write(id + ",")
            message = f"meal card issued to user id {id}"
        else:
            message = f"meal card already issued to user id {id}"
    else:
        message = f"user id {id} is not registered"
    return message

def generate_report():
    with open("issuedMeals.txt", "r") as f:
        members = f.read()
        issued_meals_array = members.split(",")
        issued_meals_array.pop()
        message = ""
        for id in issued_meals_array:
            message = message + "\n" + "student id " + id
        with open("issuedMeals.txt","w") as f:
            f.write("")
    return "free meals issued to the following \n" + message

def log_out():
    global login
    login = False

def menu(number):
    if number == 1:
        id = input("enter new user id:\n")
        print(add_gym_member(id))
    elif number == 2:
        id = input("enter user id to delete:\n")
        print(remove_gym_member(id))
    elif number == 3:
        id = id = input("enter user id for free meal:\n")
        print(issue_meal_card(id))
    elif number == 4:
        print(generate_report())
    elif number == 5:
        log_out()
