
import cafeteria
loggedIn = cafeteria.login
print("welcome to MUST cafeterial \n")
attempts = 0

while True:
    if cafeteria.login:
        print("""
        Select Option:
            1. Add new gym member
            2. Delete gym member
            3. issue meal card
            4. Print report
            5. Logout 
        """)
        option = int(input("\t ::"))
        cafeteria.menu(option)
    else:
        id = (input("enter your credentials to log in OR (\"exit\" to close):\n"))
        if id == "exit":
            break
        else:
            print(cafeteria.log_in(id))
            attempts += 1
        if attempts == 3:
            print("attempts exceeds 3 times, system locked")
            break
